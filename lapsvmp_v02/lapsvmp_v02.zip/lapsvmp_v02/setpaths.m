function setpaths()
    paths = genpath(cd);
    path(path, paths);
return